class drawable_anydpi_v26 {
}